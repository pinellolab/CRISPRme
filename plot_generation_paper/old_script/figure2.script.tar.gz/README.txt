To generate the plots contained in main paper figure2
the user just need to call this script,

./extract_data.sh IODOOKZQ2Y.bestMerge.txt IODOOKZQ2Y.bestMerge.txt.integrated_results.tsv

the script will take care of extracting and filtering the data and will generate the figures as reported in the main paper.

if any issue with python packages, the user need to install crisprme,
https://github.com/pinellolab/CRISPRme
